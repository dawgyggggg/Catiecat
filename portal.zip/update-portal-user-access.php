<?php
require_once("inc/config.php");
if(!isset($_SESSION["Klog_uname"]) && !isset($_SESSION["Klog_ucat"]))
{
	header("location: login.php");
	exit;
} 
if($_SESSION['Klog_Portal'] != '111')
{
	header("location: ".LOGOUT_PATH);
	exit;
}
$id = $db->mctdecode($_REQUEST['EditAdminCat'],'Mdp');
$id = trim($id,"Mdp");
$results=$db->fetchSingleRow('uoh_kpc_sum','admin_id',$id);
$rac = "";
$racARR = array();
if(trim($results->r_ac) == NULL)
{
	$rac = "";
	$racARR = array();
}
else
{
	$rac = trim($results->r_ac);
	$racARR = explode(',',$rac);
}
//echo "<pre>"; print_r($racARR); exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo TITLE;?></title>
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo FAV_ICON_PATH;?>">
<!-- DataTables -->
<?php /*?><link href="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo PLUGINS_PATH;?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css"><?php */?>
<!-- App css -->
<link href="<?php echo ASSETS_PATH;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/jquery-ui.min.css" rel="stylesheet">
<link href="<?php echo ASSETS_PATH;?>assets/css/icons.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/metisMenu.min.css" rel="stylesheet" type="text/css">
<?php /*?><link href="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"><?php */?>
<link href="<?php echo ASSETS_PATH;?>assets/css/app.min.css" rel="stylesheet" type="text/css">
</head>
<body class="dark-sidenav">
    <!-- Left Sidenav -->
<?php require_once("inc/sidebar.php"); ?>
<!-- end left-sidenav-->
<div class="page-wrapper">
  <!-- Top Bar Start -->
  <?php require_once("inc/header.php"); ?>

        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="row">
                                <div class="col">
                                    <h4 class="page-title">Update  User/Admin Portal Access</h4>
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Update Access Level</a></li>
                                    </ol>
                                </div>
                                <!--end col-->
                                 <div class="col-auto align-self-center"><a href="portal-admins.php"><button type="button" class="btn btn-primary waves-effect waves-light">Go Back</button></a></div>
                                <!--end col-->
                            </div>
                            <!--end row-->
                        </div>
                        <!--end page-title-box-->
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            
                            <!--end card-header-->
<div class="card-body">
    <div class="row">
        <div class="col-lg-12">
<form class="form-group" id="addcampus" name="addcampus" method="post" action="portal-admins.php">
<div class="col-md-12">
    <div class="col-lg-12 float-left mb-4" style="border:1px solid #B6B6B6; height:auto;">
        <div class="col-sm-4 text-left float-left">
        <h5><strong><u>Name:</u>&nbsp;&nbsp;</strong><?php echo $results->admin_name;?></h5></div>
        <div class="col-sm-4 text-left float-left">
        <h5><strong><u>Email:</u>&nbsp;&nbsp;</strong><?php echo $results->admin_email;?></h5></div>
        <div class="col-sm-4 text-left float-left">
        <h5><strong><u>Username:</u>&nbsp;&nbsp;</strong><?php echo $results->zhgift;?></h5></div>
        </div>
    <div class="col-lg-12">
        <div class="checkbox checkbox-success">
        <?php
		if(in_array("chkall",$racARR))
		{
			$chkedall = "checked='checked'";
		}
		else
		{
			$chkedall = "";
		}
		?>
        <input id="chkall" type="checkbox" name="mod[]" value="chkall" <?php echo $chkedall;?>>
        <label for="chkall"><h4 class="pt-0 mt-0"><strong>Check All (Important: If you want to give full access to this user)</strong></h4>
        </label></div>
    </div>
<?php
//echo "<pre>"; print_r($_SESSION); exit;
$result=$db->query("SELECT * FROM uoh_zm_portals_mode 
					WHERE 
					port_ide = '".$_SESSION['Klog_Portal']."' AND
					mod_parent = '0'
					ORDER BY mod_id ASC");
$i=1;
foreach($result as $key) 
{
	if(in_array($key['mod_id'],$racARR))
	{
		$chked = "checked='checked'";
	}
	else
	{
		$chked = "";
	}
?> 
<div class="col-md-12 float-left">
    <div class="checkbox checkbox-primary">
        <input id="<?php echo $key['mod_id'];?>" type="checkbox" name="mod[]" value="<?php echo $key['mod_id'];?>" <?php echo $chked;?>>
        <label for="<?php echo $key['mod_id'];?>"><h5 class="mt-0 pt-0"><strong><?php echo $i.": ".$key['mod_title'];?></strong></h5></label></div>
        <?php
		$resultA=$db->query("SELECT * FROM uoh_zm_portals_mode 
					WHERE 
					port_ide = '".$_SESSION['Klog_Portal']."' AND
					mod_parent = '".$key['mod_id']."'
					ORDER BY mod_id ASC");
		foreach($resultA as $keyA) {
			if(in_array($keyA['mod_id'],$racARR))
			{
				$chkedA = "checked='checked'";
			}
			else
			{
				$chkedA = "";
			}
		?>
        <div class="col-md-4 float-left pl-4">
        <div class="checkbox checkbox-pink">
        <input id="<?php echo $keyA['mod_id'];?>" type="checkbox" name="mod[]" value="<?php echo $keyA['mod_id'];?>" <?php echo $chkedA;?>>
        <label for="<?php echo $keyA['mod_id'];?>"><h6 class="mt-0 pt-0"><?php echo $keyA['mod_title'];?></h6></label></div></div>
        <?php } ?>
    </div>
<?php $i++; } ?>
</div>

<div class="form-group col-lg-12 float-left">
 
<button name="Update8UserAdminAccess" type="submit" class="btn btn-primary btn-lg float-right">Update User/Admin Access</button></div> 
<input name="kmg" type="hidden" value="<?php echo $_REQUEST['EditAdminCat'];?>">
<?php /*?><input type="hidden" name="dmg" id="dmg" value="<?php echo base64_encode($_SESSION['Klog_Depart']);?>"><?php */?>
</form>
        </div>
    </div>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <?php require_once("inc/footer-main.php"); ?>
        </div>
    </div>
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/metismenu.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/waves.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/feather.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/simplebar.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/moment.js"></script>
<?php /*?><script src="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.js"></script><?php */?>
<!-- App js -->
<script src="<?php echo ASSETS_PATH;?>assets/js/app.js"></script>
<?php /*?><script>$('#datatable').DataTable();</script><?php */?>
<script>
$('#dang').delay(5000).fadeOut('slow');
$('#suc').delay(5000).fadeOut('slow');
$("#100").addClass("mm-show");
$("#1000").addClass("mm-active");

$(document).on('click','#chkall',function () {
    if(this.checked){
        $('input[type=checkbox]').attr('checked',true);
    }
    else{
        $('input[type=checkbox]').removeAttr('checked');
    }
});
</script>
</body>
</html>