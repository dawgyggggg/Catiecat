<?php
require_once("inc/config.php");
if(!isset($_SESSION["Klog_uname"]) && !isset($_SESSION["Klog_ucat"]))
{
	header("location: login.php");
	exit;
} 
if($_SESSION['Klog_Portal'] != '111')
{
	header("location: ".LOGOUT_PATH);
	exit;
}
$id = $db->mctdecode($_REQUEST['EditAdminCat'],'Mdp');
$id = trim($id,"Mdp");
$results=$db->fetchSingleRow('uoh_kpc_sum','admin_id',$id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo TITLE;?></title>
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo FAV_ICON_PATH;?>">
<!-- DataTables -->
<link href="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo PLUGINS_PATH;?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
<!-- App css -->
<link href="<?php echo ASSETS_PATH;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/jquery-ui.min.css" rel="stylesheet">
<link href="<?php echo ASSETS_PATH;?>assets/css/icons.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/metisMenu.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/app.min.css" rel="stylesheet" type="text/css">
</head>
<body class="dark-sidenav">
    <!-- Left Sidenav -->
<?php require_once("inc/sidebar.php"); ?>
<!-- end left-sidenav-->
<div class="page-wrapper">
  <!-- Top Bar Start -->
  <?php require_once("inc/header.php"); ?>

        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <div class="row">
                                <div class="col">
                                    <h4 class="page-title">Edit System Admin</h4>
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Update User Information</a></li>
                                    </ol>
                                </div>
                                <!--end col-->
                                 <div class="col-auto align-self-center"><a href="portal-admins.php"><button type="button" class="btn btn-primary waves-effect waves-light">Go Back</button></a></div>
                                <!--end col-->
                            </div>
                            <!--end row-->
                        </div>
                        <!--end page-title-box-->
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
                <!-- end page title end breadcrumb -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            
                            <!--end card-header-->
<div class="card-body">
    <div class="row">
        <div class="col-lg-12">
<form class="form-group" id="addcampus" name="addcampus" method="post" action="portal-admins.php">
<div class="col-lg-12">
<div class="form-group row"><label for="example-text-input" class="col-sm-2 col-form-label text-left"><strong>Full Name: </strong></label><div class="col-sm-9"><input name="aname" class="form-control" placeholder="Enter Full Name" type="text" id="example-text-input"  value="<?php echo $results->admin_name;?>" required></div></div>
<div class="form-group row"><label for="example-text-input" class="col-sm-2 col-form-label text-left"><strong>Email: </strong></label><div class="col-sm-9"><input name="aemail" class="form-control" placeholder="Enter Email" type="text" id="example-text-input" value="<?php echo $results->admin_email;?>" required></div></div>
<div class="form-group row"><label for="example-text-input" class="col-sm-2 col-form-label text-left"><strong>Username: </strong></label><div class="col-sm-9"><input name="auser" class="form-control" placeholder="Enter Username" type="text" id="example-text-input" value="<?php echo $results->zhgift;?>" required></div></div>
</div>
<div class="form-group col-lg-12 float-left">
 
<button name="EditUserAdminInfo" type="submit" class="btn btn-primary btn-lg float-right">Update Changes</button></div> 
<input name="Edit" type="hidden" value="<?php echo $_REQUEST['EditAdminCat'];?>">
<input type="hidden" name="depart" id="depart" value="<?php echo $_SESSION['Klog_Depart'];?>">
</form>
        </div>
    </div>
</div>
                        </div>
                    </div>
                </div>
            </div>
            <?php require_once("inc/footer-main.php"); ?>
        </div>
    </div>
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/metismenu.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/waves.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/feather.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/simplebar.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/moment.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.js"></script>
<!-- App js -->
<script src="<?php echo ASSETS_PATH;?>assets/js/app.js"></script>
<script>$('#datatable').DataTable();</script>
<script>
$('#dang').delay(5000).fadeOut('slow');
$('#suc').delay(5000).fadeOut('slow');
$("#100").addClass("mm-show");
$("#1000").addClass("mm-active");
</script>
</body>
</html>