<?php
require_once("../inc/config.php");
if(!isset($_SESSION["Klog_uname"]) && !isset($_SESSION["Klog_ucat"]))
{
	header("location: login.php");
	exit;
}
if($_SESSION['Klog_Portal'] != '2002')
{
	header("location: ".LOGOUT_PATH);
	exit;
}

if(isset($_REQUEST['AddAdminCat']))
{
	$data=array(
	'port_title'=>trim($_REQUEST['aname']));
	$res=$db->checkExist('uoh_zm_portals',$data);
	if ($res==true) {
		$error = "Record Alreday Exists!";		
	} else {
		$add=array(
		'port_ide'=>trim($_REQUEST['acde']),
		'port_title'=>trim($_REQUEST['aname']),
		'dated'=>date('d-m-Y h:i:s A',time()),
		'status'=>1);
		$db->insert('uoh_zm_portals',$add);
		$success="Record added Successfully!";
	}
}

/*if(isset($_REQUEST['DelAdminCat']))
{
	$del = $db->mctdecode($_REQUEST['DelAdminCat'],'Mdp');
	$del = trim($del,"Mdp");
	$db->delete('uoh_zm_portals','port_id',$del);
	$success="Record deleted Successfully!";
}*/

if(isset($_REQUEST['st']))
{
	$id = $db->mctdecode($_REQUEST['id'],'Mdp');
	$id = trim($id,"Mdp");
	$data=array('status'=>trim($_REQUEST['st']));
	$db->update('uoh_zm_portals',$data,'port_id',$id);
	$success="Status updated Successfully!";
}
if(isset($_REQUEST['EditUserPortalInfo']))
{
	$update=array(
	'port_ide'=>trim($_REQUEST['acde']),
	'port_title'=>trim($_REQUEST['aname']));
	$port_id = $db->mctdecode($_REQUEST['Edit'],'Mdp');
	$port_id = trim($port_id,"Mdp");
	$db->update('uoh_zm_portals',$update,'port_id',trim($port_id));
	$success="Record updated Successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<title><?php echo TITLE;?></title>
<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo FAV_ICON_PATH;?>">
<!--select2 css for dropdown-->
<?php /*?><link href="<?php echo PLUGINS_PATH;?>plugins/select2/select2.min.css" rel="stylesheet" type="text/css"><?php */?>
<!--select2 css for dropdown-->
<!-- DataTables -->
<link href="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo PLUGINS_PATH;?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
<!-- App css -->
<link href="<?php echo ASSETS_PATH;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/jquery-ui.min.css" rel="stylesheet">
<link href="<?php echo ASSETS_PATH;?>assets/css/icons.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS_PATH;?>assets/css/metisMenu.min.css" rel="stylesheet" type="text/css">
<?php /*?><link href="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css"><?php */?>
<link href="<?php echo ASSETS_PATH;?>assets/css/app.min.css" rel="stylesheet" type="text/css">
</head>
<body class="dark-sidenav">
<!-- Left Sidenav -->
<?php require_once("inc/sidebar.php"); ?>
<!-- end left-sidenav-->
<div class="page-wrapper">
  <!-- Top Bar Start -->
  <?php require_once("inc/header.php"); ?>
  <!-- Top Bar End -->
  <!-- Page Content-->
   <div class="page-content">
    <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
        <div class="col-sm-12">
          <div class="page-title-box">
            <div class="row">
              <div class="col">
                <h4 class="page-title">System Portals</h4>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="javascript:void(0);">Configuration</a></li>
                  <li class="breadcrumb-item"><a href="javascript:void(0);">Portals</a></li>
                  <li class="breadcrumb-item active">List</li>
                </ol>
              </div>
			   <div  class="col">
              <?php
			  if(isset($error))
			  {
					echo "<div id='dang' class='alert alert-danger border-0' role='alert'><strong>Oops!</strong> ".$error."</div>";
			  }
			  if(isset($success))
			  {
					echo "<div id='suc' class='alert alert-success border-0' role='alert'><strong>Well done!</strong> ".$success."</div>";
			  }
			  ?>
              </div>
              <div class="col-auto align-self-center"><button type="button" class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#exampleModalCenter">Add System Portal</button>
              <!--end col-->
            </div>
            <!--end row-->
          </div>
          <!--end page-title-box-->
        </div>
        <!--end col-->
      </div>
      <!--end row-->
	  </div>
	  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h6 class="modal-title m-0" id="exampleModalCenterTitle">Add System Portal</h6>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="la la-times"></i></span></button>
                    </div>
                    <form class="form-group" id="addcampus" name="addcampus" method="post" action="portals.php">
                    <!--end modal-header-->
                    <div class="modal-body">
                      <div class="row">
                       
                        <!--end col-->
                        <div class="col-lg-12">
                          <div class="form-group row"><label for="example-text-input" class="col-sm-3 col-form-label text-right"><strong>Portal Name:</strong></label><div class="col-sm-9"><input name="aname" class="form-control" placeholder="Enter Portal Name" type="text" value="" id="example-text-input" required></div></div>
                          <div class="form-group row"><label for="example-text-input" class="col-sm-3 col-form-label text-right"><strong>Portal Code:</strong></label><div class="col-sm-9"><input name="acde" class="form-control" placeholder="Enter Portal Code" type="text" value="" id="example-text-input" required></div></div>
                        </div>
                        <!--end col-->
                      </div>
                      <!--end row-->
                    </div>
                    <!--end modal-body-->
                    <div class="modal-footer">
                      
                     <button name="AddAdminCat" type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                    </div>
                    <!--end modal-footer-->
                    </form>
                  </div>
                  <!--end modal-content-->
                </div>
                <!--end modal-dialog-->
              </div>
      <!-- end page title end breadcrumb -->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                  <tr>
                    <th width="5%">Sr#</th>
				    <th width="75%">Portal Name</th>
                    <th width="10%">Status</th>
                   	<th width="10%">Action</th>
                  </tr>
                </thead>
                <tbody>
<?php
/*$result=$db->query("SELECT * FROM uoh_zm_portals 
					WHERE 
					depart_id = '".$_SESSION['Klog_Depart']."' 
					ORDER BY port_id DESC");*/
$result=$db->query("SELECT * FROM uoh_zm_portals ORDER BY port_id DESC");
$i=1;
foreach ($result as $key) 
{
if($key['status'] == 1)
{
	$st = 0;
	$id = $db->mctencode("Mdp".$key['port_id']."Mdp","Mdp");
	$status = "<a href='portals.php?st=$st&id=$id'><span class='badge badge-success'>Enable</span></a>";
}
else
{
	$st = 1;
	$id = $db->mctencode("Mdp".$key['port_id']."Mdp","Mdp");
	$status = "<a href='portals.php?st=$st&id=$id'><span class='badge badge-danger'>Disable</span></a>";
}
?>
  <tr>
    <td width="5%"><?php echo $i;?></td>
    <td><p class="d-inline-block align-middle mb-0"><?php echo $key['port_title'];?></p></td>
   <td><?php echo $status;?></td>
    <td><a href="edit-portals.php?EditAdminCat=<?php echo $db->mctencode("Mdp".$key['port_id']."Mdp","Mdp");?>" class="mr-2"><i class="las la-pen text-info font-18"></i></a> <?php /*?><a href="portal-admins.php?DelAdminCat=<?php echo $db->mctencode("Mdp".$key['port_id']."Mdp","Mdp");?>" onClick="return confirm('Would you like to delete this record?');"><i class="las la-trash-alt text-danger font-18"></i></a><?php */?></td>
  </tr>
                   <?php $i++; } ?>  
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- end col -->
      </div>
      <!-- end row -->
    </div>
    <!-- container -->
    <?php require_once("inc/footer-main.php"); ?>
    <!--end footer-->
  </div>
  <!-- end page content -->
</div>
<!-- end page-wrapper -->
<!-- jQuery  -->
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/metismenu.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/waves.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/feather.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/simplebar.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/js/moment.js"></script>
<?php /*?><script src="<?php echo PLUGINS_PATH;?>plugins/daterangepicker/daterangepicker.js"></script><?php */?>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo PLUGINS_PATH;?>plugins/datatables/dataTables.bootstrap4.min.js"></script>
<?php /*?><script src="<?php echo PLUGINS_PATH;?>plugins/select2/select2.min.js"></script>
<script src="<?php echo ASSETS_PATH;?>assets/pages/jquery.forms-advanced.js"></script><?php */?>
<!-- App js -->
<script src="<?php echo ASSETS_PATH;?>assets/js/app.js"></script>
<!--<script>$('#datatable').DataTable();</script>-->
<script>
$('#datatable').dataTable({
    aLengthMenu: [
        [10,25, 50, 100, 200, -1],
        [10,25, 50, 100, 200, "All"]
    ] 
     
});
</script>
<script>
$('#dang').delay(5000).fadeOut('slow');
$('#suc').delay(5000).fadeOut('slow');

/*function subSearch()
{
	$( "#SearchProg" ).submit();
}*/
</script>
</body>
</html>
